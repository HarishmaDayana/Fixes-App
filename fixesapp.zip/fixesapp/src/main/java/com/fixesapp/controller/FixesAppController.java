package com.fixesapp.controller;

import java.sql.Date;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.fixesapp.model.User;
import com.fixesapp.model.Worker;
import com.fixesapp.service.FixesAppService;

@Controller
@SessionAttributes({ "userid" })
public class FixesAppController {

	@Autowired
	FixesAppService fixesservice;
	int workerId;
	Date workerDate;
	String timeSlot;
	String contactNumber;
	int worker_cost;
	int userid;
	String wlogin_id;

	@GetMapping("/home_page")
	public String homepage() {

		return "homepage";
	}

	@GetMapping("/user_login_page")
	public String loginpage(Model model) {
		model.addAttribute("user", new User());
		return "loginpage";
	}

	@GetMapping("/worker_login_page")
	public String loginpageWorker(Model model) {

		model.addAttribute("worker", new Worker());
		return "workerlogin";
	}

	@GetMapping("/user_register_page")
	public String registeruser(Model model) {
		model.addAttribute("users", new User());
		return "registeruser";
	}

	@GetMapping("/worker_register_page")
	public String registerworker(Model model) {
		model.addAttribute("workers", new Worker());
		return "registerworker";
	}

	@PostMapping("/user_registration")
	public String userregistration(Model model, @Valid @ModelAttribute("users") User users, BindingResult result) {
		if (result.hasErrors()) {
			return "registeruser";
		}
		boolean userRegistration = fixesservice.registerUser(users);

		if (userRegistration) {
			return "registerusersuccess";

		}
		model.addAttribute("registererror", "Cannot register! Please give a unique log in id!!");
		return "registeruser";

	}

	@PostMapping("/worker_registration")
	public String workerregistration(Model model, @Valid @ModelAttribute("workers") Worker workers,
			BindingResult result) {
		if (result.hasErrors()) {
			return "registerworker";
		}
		boolean workerRegistration = fixesservice.registerWorker(workers);
		if (workerRegistration) {
			return "registerworkersuccess";
		}

		model.addAttribute("registererror", "Cannot register! Please give a unique log in id!!");
		return "registerworker";
	}

	@PostMapping("/validate_user")
	public String validateuser(@ModelAttribute("user") User user, Model model) {
		String user_login = user.getUser_log_in_id();
		String password = user.getUser_password();

		if (fixesservice.validateUser(user_login, password) == 0) {
			model.addAttribute("user_login_error", "Incorrect log in!! please try again");
			return "loginpage";
		}

		else {

			model.addAttribute("user_id", fixesservice.validateUser(user_login, password));
			userid = fixesservice.validateUser(user_login, password);
			return "loginsuccess";
		}
	}

	@GetMapping("/list_worker")
	public String listworker(Model model) {
		model.addAttribute("workers", new Worker());
		model.addAttribute("list_of_all_workers", fixesservice.listworker());
		return "listworker";
	}

	@ModelAttribute("occupation")
	public Map<String, String> qualificationdetails() {
		Map<String, String> rlist = new TreeMap<>();
		rlist.put("mechanic", "mechanic");
		rlist.put("electrician", "electrician");
		rlist.put("carpenter", "carpenter");
		rlist.put("plumber", "plumber");
		return rlist;
	}

	@ModelAttribute("cost")
	public Map<String, String> plandetails() {
		Map<String, String> rlist = new TreeMap<>();
		rlist.put("500", "500");
		rlist.put("600", "600");
		rlist.put("700", "700");
		rlist.put("800", "800");
		return rlist;
	}

	@PostMapping("/criteria")
	public String listselectedworker(@ModelAttribute("workers") Worker workers, Model model) {

		List<Worker> listselectedworker = fixesservice.listselectedworker(workers.getCost(), workers.getLocation(),
				workers.getOccupation());
		if (listselectedworker.isEmpty()) {
			model.addAttribute("norecord", "no record matching your criteria");
		}
		model.addAttribute("selectedlist",
				fixesservice.listselectedworker(workers.getCost(), workers.getLocation(), workers.getOccupation()));
		return "listselectedworker";
	}

	@GetMapping("/hireform")
	public String hireForm(@RequestParam int workerid, @RequestParam int cost, Model model) {
		workerId = workerid;
		worker_cost = cost;

		model.addAttribute("workerid", workerid);
		model.addAttribute("cost", cost);
		return "hireform";
	}

	@PostMapping("/hireworker")
	public String hireworker(@RequestParam Date work_date, @RequestParam String time_slot,
			@RequestParam String contact_number, Model model) {
		workerDate = work_date;
		timeSlot = time_slot;
		contactNumber = contact_number;

		if (fixesservice.workerAvailability(workerId, workerDate, timeSlot).equals("workeravailable")) {

			model.addAttribute("cost", worker_cost);
			return "payment";
		} else {
			model.addAttribute("errorMessaage", "worker is already booked");
			return "redirect:/list_workers?errorMessage";
		}
	}

	@PostMapping("/payment_success")
	public String paymentSuccess() {
		fixesservice.hireWorker(userid, workerId, contactNumber, workerDate, timeSlot);
		return "paymentsuccess";
	}

	@GetMapping("/list_workers")
	public String listworker(Model model, @RequestParam String errorMessage) {
		model.addAttribute("workers", new Worker());

		model.addAttribute("list_of_all_workers", fixesservice.listworker());
		model.addAttribute("errorMessage", "the worker is already booked");

		return "listworker";
	}

	@PostMapping("/validate_worker")
	public String validateWorker(@ModelAttribute("worker") Worker worker, Model model) {
		wlogin_id = worker.getWorker_log_in_id();
		if (fixesservice.validateWorkerLogin(worker.getWorker_log_in_id(), worker.getWorker_password()) == 0) {
			model.addAttribute("errorMessage", "incorrect log in!! please try again");
			return "workerlogin";
		}

		else {
			model.addAttribute("worker_id",
					fixesservice.validateWorkerLogin(worker.getWorker_log_in_id(), worker.getWorker_password()));
			int workerid = fixesservice.validateWorkerLogin(worker.getWorker_log_in_id(), worker.getWorker_password());
			if (fixesservice.listWorksForWorker(workerid).isEmpty()) {
				model.addAttribute("emptyworklist", "there is no pending work for you");
			}
			model.addAttribute("worklist", fixesservice.listWorksForWorker(workerid));

			return "loginsuccessworker";
		}
	}

	@RequestMapping("/deleteoldrecord")
	public String deleteoldrecord(@RequestParam int id, Model model) {
		if (fixesservice.deleteOldRecords(id) != 0) {
			model.addAttribute("delete", "Your old records got deleted successfully");
		}

		if (fixesservice.listWorksForWorker(id).isEmpty()) {
			model.addAttribute("emptyworklist", "there is no pending work for you");
		}
		model.addAttribute("worklist", fixesservice.listWorksForWorker(id));

		return "loginsuccessworker";
	}
}
