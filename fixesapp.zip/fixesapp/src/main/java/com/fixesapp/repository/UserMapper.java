package com.fixesapp.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fixesapp.model.User;

public class UserMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub

		User u = new User();
		u.setUser_id(rs.getInt("user_id"));
		u.setUser_name(rs.getString("user_name"));
		u.setMobile_number(rs.getString("mobile_number"));
		u.setEmail(rs.getString("email"));
		u.setAddress(rs.getString("address"));
		u.setLocation(rs.getString("location"));
		u.setUser_log_in_id(rs.getString("user_log_in_id"));
		u.setUser_password(rs.getString("user_password"));
		return u;

	}
}
