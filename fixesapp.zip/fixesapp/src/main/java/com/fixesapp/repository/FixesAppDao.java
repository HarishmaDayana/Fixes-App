package com.fixesapp.repository;

import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import com.fixesapp.model.HireDetails;
import com.fixesapp.model.User;
import com.fixesapp.model.Worker;

public interface FixesAppDao {

	int validateUser(String user_login, String password);

	List<Worker> listworker();

	List<Worker> listselectedworker(Integer cost, String location, String occupation);

	int workerAvailability(int workerId, Date workerDate, String timeSlot);

	boolean registerWorker(@Valid Worker workers);

	boolean registerUser(@Valid User users);

	int validateWorkerLogin(String worker_log_in_id, String worker_password);

	String hireWorker(int userid, int workerId, String contactNumber, Date workerDate, String timeSlot);

	List<HireDetails> listWorksForWorker(Integer worker_id);

	int deleteOldRecords(int id);

}
