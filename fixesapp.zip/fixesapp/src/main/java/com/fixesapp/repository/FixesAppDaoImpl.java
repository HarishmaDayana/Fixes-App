package com.fixesapp.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import com.fixesapp.model.HireDetails;
import com.fixesapp.model.User;
import com.fixesapp.model.Worker;

@Repository

public class FixesAppDaoImpl implements FixesAppDao {
	@Autowired
	JdbcTemplate jdbcTemplate;

	@Override
	public int validateUser(String user_login, String password) {
		String sql = "select user_id from User where user_log_in_id=? and user_password=?";
		int result = 0;
		try {
			result = jdbcTemplate.queryForObject(sql, new RowMapper<Integer>() {

				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

					return rs.getInt("user_id");
				}
			}, user_login, password);
		} catch (Exception e) {

		}

		return result;
	}

	@Override

	public List<Worker> listworker() {
		String sql = "select * from Worker order by occupation asc";
		List<Worker> result = new ArrayList<Worker>();
		try {
			result = jdbcTemplate.query(sql, new WorkerMapper());
		} catch (Exception e) {

		}
		return result;
	}

	@Override
	public List<Worker> listselectedworker(Integer cost, String location, String occupation) {

		String sql = "select * from Worker where location=? and cost=? and occupation=?;";
		List<Worker> result = new ArrayList<Worker>();
		try {
			result = jdbcTemplate.query(sql, new WorkerMapper(), location, cost, occupation);
		} catch (Exception e) {

		}
		return result;

	}

	@Override
	public int workerAvailability(int workerId, Date workerDate, String timeSlot) {
		int result = 0;
		if (timeSlot.equals("work_slot1")) {

			String sql = "select worker_id from HireDetails where worker_id=? and work_date=? and work_slot1 is not null";
			try {
				result = jdbcTemplate.queryForObject(sql, new RowMapper<Integer>() {

					public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

						return rs.getInt("worker_id");
					}
				}, workerId, workerDate);
			} catch (Exception e) {
				result = 0;
			}
			return result;

		}
		if (timeSlot.equals("work_slot2")) {

			String sql = "select worker_id from HireDetails where worker_id=? and work_date=? and work_slot2 is not null";
			try {
				result = jdbcTemplate.queryForObject(sql, new RowMapper<Integer>() {

					public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

						return rs.getInt("worker_id");
					}
				}, workerId, workerDate);
			} catch (Exception e) {
				result = 0;
			}
			return result;

		}
		if (timeSlot.equals("work_slot3")) {

			String sql = "select worker_id from HireDetails where worker_id=? and work_date=? and work_slot3 is not null";
			try {
				result = jdbcTemplate.queryForObject(sql, new RowMapper<Integer>() {

					public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

						return rs.getInt("worker_id");
					}
				}, workerId, workerDate);
			} catch (Exception e) {
				result = 0;
			}
			return result;

		}
		return result;

	}

	@Override
	public boolean registerWorker(@Valid Worker workers) {

		String sql = "insert into Worker(worker_name,mobile_number,email,address,location,occupation,cost,worker_log_in_id,worker_password) values(?,?,?,?,?,?,?,?,?)";
		boolean truth = false;
		int count = 0;
		try {
			count = jdbcTemplate.update(sql, workers.getWorker_name(), workers.getMobile_number(), workers.getEmail(),
					workers.getAddress(), workers.getLocation(), workers.getOccupation(), workers.getCost(),
					workers.getWorker_log_in_id(), workers.getWorker_password());
		} catch (Exception e) {

		}
		if (count > 0)
			truth = true;
		return truth;
	}

	@Override
	public boolean registerUser(@Valid User users) {
		// TODO Auto-generated method stub
		String sql = "insert into User(user_name,mobile_number,email,address,location,user_log_in_id,user_password) values(?,?,?,?,?,?,?)";
		boolean truth = false;
		int count = 0;
		try {
			count = jdbcTemplate.update(sql, users.getUser_name(), users.getMobile_number(), users.getEmail(),
					users.getAddress(), users.getLocation(), users.getUser_log_in_id(), users.getUser_password());

		} catch (Exception e) {

		}

		if (count > 0)
			truth = true;

		return truth;
	}

	@Override
	public int validateWorkerLogin(String worker_log_in_id, String worker_password) {
		// TODO Auto-generated method stub
		String sql = "select worker_id from Worker where worker_log_in_id=? and worker_password=?";
		int result = 0;
		try {
			result = jdbcTemplate.queryForObject(sql, new RowMapper<Integer>() {

				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

					return rs.getInt("worker_id");
				}
			}, worker_log_in_id, worker_password);
		} catch (Exception e) {

		}

		return result;
	}

	@Override
	public String hireWorker(int userid, int workerId, String contactNumber, Date workerDate, String timeSlot) {
		String attempt = "hirefail";
		String sqlalreadydate = "select worker_id from HireDetails where worker_id=? and work_date=?";

		int flag = 0;
		try {
			flag = jdbcTemplate.queryForObject(sqlalreadydate, new RowMapper<Integer>() {

				public Integer mapRow(ResultSet rs, int rowNum) throws SQLException {

					return rs.getInt("worker_id");
				}
			}, workerId, workerDate);
		} catch (Exception e) {

		}

		if (flag == 0)

		{

			if (timeSlot.equals("work_slot1")) {

				String sql = "insert into HireDetails(user_id_work_slot1,worker_id,work_date,work_slot1)values(?,?,?,?)";

				if (jdbcTemplate.update(sql, userid, workerId, workerDate, contactNumber) != 0) {

					attempt = "hiresuccess";

				}

			}

			if (timeSlot.equals("work_slot2")) {
				String sql = "insert into HireDetails(user_id_work_slot2,worker_id,work_date,work_slot2)values(?,?,?,?)";

				if (jdbcTemplate.update(sql, userid, workerId, workerDate, contactNumber) != 0) {
					attempt = "hiresuccess";

				}

			}

			if (timeSlot.equals("work_slot3")) {
				String sql = "insert into HireDetails(user_id_work_slot3,worker_id,work_date,work_slot3)values(?,?,?,?)";

				if (jdbcTemplate.update(sql, userid, workerId, workerDate, contactNumber) != 0) {
					attempt = "hiresuccess";

				}

			}

		}

		else {
		
			if (timeSlot.equals("work_slot1")) {

				String sql = " update HireDetails set user_id_work_slot1=?,work_slot1=? where worker_id=? and work_date=?";

				if (jdbcTemplate.update(sql, userid, contactNumber, workerId, workerDate) != 0) {

					attempt = "hiresuccess";

				}

			}

			if (timeSlot.equals("work_slot2")) {
				String sql = "update HireDetails set user_id_work_slot2=?,work_slot2=? where worker_id=? and work_date=?";

				if (jdbcTemplate.update(sql, userid, contactNumber, workerId, workerDate) != 0) {
					attempt = "hiresuccess";

				}

			}

			if (timeSlot.equals("work_slot3")) {
				String sql = "update HireDetails set user_id_work_slot3=?,work_slot3=? where worker_id=? and work_date=?";

				if (jdbcTemplate.update(sql, userid, contactNumber, workerId, workerDate) != 0) {
					attempt = "hiresuccess";

				}

			}

		}
		return attempt;

	}

	@Override
	public List<HireDetails> listWorksForWorker(Integer worker_id) {
		String sql = "select * from HireDetails where worker_id=? ";
		List<HireDetails> result = new ArrayList<>();
		try {
			result = jdbcTemplate.query(sql, new HireDetailsMapper(), worker_id);
		} catch (Exception e) {

		}
		return result;
	}

	@Override
	public int deleteOldRecords(int id) {
		String sql = "delete from HIREDETAILS where work_date<CURDATE() and worker_id=?";

		int result = 0;
		try {
			result = jdbcTemplate.update(sql, id);
		} catch (Exception e) {

		}
		return result;

	}
}
