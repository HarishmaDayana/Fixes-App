package com.fixesapp.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fixesapp.model.HireDetails;

public class HireDetailsMapper implements RowMapper<HireDetails> {

	@Override
	public HireDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub

		HireDetails h = new HireDetails();
		h.setWorker_id(rs.getInt("worker_id"));
		h.setWork_date(rs.getDate("work_date"));
		h.setUser_id_work_slot1(rs.getInt("user_id_work_slot1"));
		h.setWork_slot1(rs.getString("work_slot1"));
		h.setUser_id_work_slot2(rs.getInt("user_id_work_slot2"));
		h.setWork_slot2(rs.getString("work_slot2"));
		h.setUser_id_work_slot3(rs.getInt("user_id_work_slot3"));
		h.setWork_slot3(rs.getString("work_slot3"));

		return h;
	}
}
