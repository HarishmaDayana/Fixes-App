package com.fixesapp.repository;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.fixesapp.model.Worker;

public class WorkerMapper implements RowMapper<Worker> {

	@Override
	public Worker mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub

		Worker w = new Worker();
		w.setWorker_id(rs.getInt("worker_id"));
		w.setWorker_name(rs.getString("worker_name"));
		w.setMobile_number(rs.getString("mobile_number"));
		w.setEmail(rs.getString("email"));
		w.setAddress(rs.getString("address"));
		w.setLocation(rs.getString("location"));
		w.setOccupation(rs.getString("occupation"));
		w.setCost(rs.getInt("cost"));
		w.setWorker_log_in_id(rs.getString("worker_log_in_id"));
		w.setWorker_password(rs.getString("worker_password"));
		return w;

	}
}
