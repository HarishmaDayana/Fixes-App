package com.fixesapp.model;

import java.util.Date;

public class HireDetails {
	private int worker_id;
	private Date work_date;
	private int user_id_work_slot1;
	private String work_slot1;
	private int user_id_work_slot2;
	private String work_slot2;
	private int user_id_work_slot3;
	private String work_slot3;

	public Integer getWorker_id() {
		return worker_id;
	}

	public void setWorker_id(Integer worker_id) {
		this.worker_id = worker_id;
	}

	public Date getWork_date() {
		return work_date;
	}

	public void setWork_date(Date work_date) {
		this.work_date = work_date;
	}

	public Integer getUser_id_work_slot1() {
		return user_id_work_slot1;
	}

	public void setUser_id_work_slot1(Integer user_id_work_slot1) {
		this.user_id_work_slot1 = user_id_work_slot1;
	}

	public String getWork_slot1() {
		return work_slot1;
	}

	public void setWork_slot1(String work_slot1) {
		this.work_slot1 = work_slot1;
	}

	public Integer getUser_id_work_slot2() {
		return user_id_work_slot2;
	}

	public void setUser_id_work_slot2(Integer user_id_work_slot2) {
		this.user_id_work_slot2 = user_id_work_slot2;
	}

	public String getWork_slot2() {
		return work_slot2;
	}

	public void setWork_slot2(String work_slot2) {
		this.work_slot2 = work_slot2;
	}

	public Integer getUser_id_work_slot3() {
		return user_id_work_slot3;
	}

	public void setUser_id_work_slot3(Integer user_id_work_slot3) {
		this.user_id_work_slot3 = user_id_work_slot3;
	}

	public String getWork_slot3() {
		return work_slot3;
	}

	public void setWork_slot3(String work_slot3) {
		this.work_slot3 = work_slot3;
	}

	public HireDetails(Integer worker_id, Date work_date, Integer user_id_work_slot1, String work_slot1,
			Integer user_id_work_slot2, String work_slot2, Integer user_id_work_slot3, String work_slot3) {
		super();
		this.worker_id = worker_id;
		this.work_date = work_date;
		this.user_id_work_slot1 = user_id_work_slot1;
		this.work_slot1 = work_slot1;
		this.user_id_work_slot2 = user_id_work_slot2;
		this.work_slot2 = work_slot2;
		this.user_id_work_slot3 = user_id_work_slot3;
		this.work_slot3 = work_slot3;
	}

	public HireDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

}
