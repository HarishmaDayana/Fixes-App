package com.fixesapp.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import javax.validation.constraints.Pattern;

public class User {

	private int user_id;
	@NotEmpty(message = "Please enter a user_name")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "Only provide alphabets")
	@Size(min = 2, max = 30, message = " should be atleast 2 letters")
	private String user_name;
	@NotEmpty(message = "Please provide contact number")
	@Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "Should contain exactly 10 numbers")
	@Size(max = 10, message = " Maximum size is 10")
	private String mobile_number;
	@NotEmpty(message = "Please enter the email")
	private String email;
	@NotEmpty(message = "Please enter your address")
	@Size(min = 2, max = 30, message = "should be atleast 2 letters and should not exceed 60 letters")
	private String address;
	@NotEmpty(message = "Please enter your location")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "Only provide alphabets")
	@Size(min = 2, max = 30, message = " should be atleast 2 letters")
	private String location;
	@NotEmpty(message = "Please give unique log_in_id")
	@Size(min = 2, max = 30, message = " should be atleast 2 letters")
	private String user_log_in_id;
	@NotEmpty(message = "Please give unique password")
	private String user_password;

	public int getUser_id() {
		return user_id;
	}

	public void setUser_id(int user_id) {
		this.user_id = user_id;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getUser_log_in_id() {
		return user_log_in_id;
	}

	public void setUser_log_in_id(String user_log_in_id) {
		this.user_log_in_id = user_log_in_id;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public User(int user_id, String user_name, String mobile_number, String email, String address, String location,
			String user_log_in_id, String user_password) {
		super();
		this.user_id = user_id;
		this.user_name = user_name;
		this.mobile_number = mobile_number;
		this.email = email;
		this.address = address;
		this.location = location;
		this.user_log_in_id = user_log_in_id;
		this.user_password = user_password;
	}

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

}
