package com.fixesapp.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

public class Worker {

	private Integer worker_id;
	@NotEmpty(message = "Please enter your name")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "Only provide alphabets")
	@Size(min = 2, max = 30, message = " should be atleast 2 letters")
	private String worker_name;
	@NotEmpty(message = "Please provide contact number")
	@Pattern(regexp = "[1-9]{1}[0-9]{9}", message = "Should contain exactly 10 numbers")
	@Size(max = 10, message = " Maximum size is 10")
	private String mobile_number;
	@NotEmpty(message = "Please enter the mailId")
	private String email;
	@NotEmpty(message = "Please enter your address")
	@Size(min = 2, max = 30, message = "should be atleast 2 letters and should not exceed 60 letters")
	private String address;
	@NotEmpty(message = "Please enter your location")
	@Pattern(regexp = "^[A-Za-z ]+$", message = "Only provide alphabets")
	@Size(min = 2, max = 30, message = " should be atleast 2 letters")
	private String location;
	@NotEmpty(message = "Please enter your occupation")
	private String occupation;
	@NotNull(message = "Please your cost")
	private Integer cost;
	@NotEmpty(message = "Please your log_in_id")
	@Size(min = 2, max = 30, message = " should be atleast 2 letters")
	private String worker_log_in_id;
	@NotEmpty(message = "Please enter a unique password")
	private String worker_password;

	public Integer getWorker_id() {
		return worker_id;
	}

	public void setWorker_id(Integer worker_id) {
		this.worker_id = worker_id;
	}

	public String getWorker_name() {
		return worker_name;
	}

	public void setWorker_name(String worker_name) {
		this.worker_name = worker_name;
	}

	public String getMobile_number() {
		return mobile_number;
	}

	public void setMobile_number(String mobile_number) {
		this.mobile_number = mobile_number;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public Integer getCost() {
		return cost;
	}

	public void setCost(Integer cost) {
		this.cost = cost;
	}

	public String getWorker_log_in_id() {
		return worker_log_in_id;
	}

	public void setWorker_log_in_id(String worker_log_in_id) {
		this.worker_log_in_id = worker_log_in_id;
	}

	public String getWorker_password() {
		return worker_password;
	}

	public void setWorker_password(String worker_password) {
		this.worker_password = worker_password;
	}

	public Worker(Integer worker_id, String worker_name, String mobile_number, String email, String address,
			String location, String occupation, Integer cost, String worker_log_in_id, String worker_password) {
		super();
		this.worker_id = worker_id;
		this.worker_name = worker_name;
		this.mobile_number = mobile_number;
		this.email = email;
		this.address = address;
		this.location = location;
		this.occupation = occupation;
		this.cost = cost;
		this.worker_log_in_id = worker_log_in_id;
		this.worker_password = worker_password;
	}

	public Worker() {
		super();
		// TODO Auto-generated constructor stub
	}

}
