package com.fixesapp.service;

import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fixesapp.model.HireDetails;
import com.fixesapp.model.User;
import com.fixesapp.model.Worker;
import com.fixesapp.repository.FixesAppDao;

@Service
public class FixesAppServiceImpl implements FixesAppService {
	@Autowired
	FixesAppDao fixesdao;

	@Override
	public int validateUser(String user_login, String password) {
		// TODO Auto-generated method stub
		return fixesdao.validateUser(user_login, password);
	}

	@Override
	public List<Worker> listworker() {
		// TODO Auto-generated method stub
		return fixesdao.listworker();
	}

	@Override
	public List<Worker> listselectedworker(Integer cost, String location, String occupation) {
		// TODO Auto-generated method stub
		return fixesdao.listselectedworker(cost, location, occupation);
	}

	@Override
	public String workerAvailability(int workerId, Date workerDate, String timeSlot) {
		// TODO Auto-generated method stub
		String availablestatus = "alreadybooked";

		if (fixesdao.workerAvailability(workerId, workerDate, timeSlot) == 0) {
			availablestatus = "workeravailable";
		}
		return availablestatus;
	}

	@Override
	public boolean registerWorker(@Valid Worker workers) {
		// TODO Auto-generated method stub
		return fixesdao.registerWorker(workers);
	}

	@Override
	public boolean registerUser(@Valid User users) {
		// TODO Auto-generated method stub
		return fixesdao.registerUser(users);
	}

	@Override
	public int validateWorkerLogin(String worker_log_in_id, String worker_password) {
		// TODO Auto-generated method stub
		return fixesdao.validateWorkerLogin(worker_log_in_id, worker_password);

	}

	@Override
	public String hireWorker(int userid, int workerId, String contactNumber, Date workerDate, String timeSlot) {
		// TODO Auto-generated method stub
		String hireStatus = "hirefail";
		if (fixesdao.hireWorker(userid, workerId, contactNumber, workerDate, timeSlot).equals("hiresuccess")) {
			hireStatus = "hiresuccess";
		}
		return hireStatus;
	}

	@Override
	public List<HireDetails> listWorksForWorker(Integer worker_id) {
		// TODO Auto-generated method stub
		return fixesdao.listWorksForWorker(worker_id);
	}

	@Override
	public int deleteOldRecords(int id) {
		// TODO Auto-generated method stub
		return fixesdao.deleteOldRecords(id);
	}
}
